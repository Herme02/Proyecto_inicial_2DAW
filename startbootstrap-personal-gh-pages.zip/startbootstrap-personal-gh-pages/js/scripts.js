
function crearFila(){
    let tabla = document.getElementById("tabla");

    texto1=prompt("Titulo del libro a comprar");
    texto2=prompt("Numero de copias");
    c1= document.createElement("td");
    c2= document.createElement("td");
    f1= document.createElement("tr");
    text1= document.createTextNode(texto1);
    text2 = document.createTextNode(texto2);
    c1.appendChild(text1);
    c2.appendChild(text2);
    f1.appendChild(c1);
    f1.appendChild(c2);
    tabla.appendChild(f1);

}

function borrarFila(){
    let tabla=document.getElementById("tabla");
    let filas = tabla.getElementsByTagName("tr");
    r=parseInt(prompt("Seleccione una fila"));
    
    let rowb = filas[r];
    rowb.remove();
}
